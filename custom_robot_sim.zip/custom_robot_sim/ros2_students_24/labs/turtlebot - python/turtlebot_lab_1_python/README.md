# Turtlebot Lab 1
Content: Putting the Controller Developed in Assignment 1 (sort of Braitenberg-Vehikel) on the real Turtlebot3 and test it on a real world test course
