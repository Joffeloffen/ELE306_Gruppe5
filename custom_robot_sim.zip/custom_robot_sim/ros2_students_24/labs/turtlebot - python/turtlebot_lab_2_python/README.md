# Turtlebot Lab 2
Content: Putting the Bug2 Controller developed in Assignments 2 and 3 on the real Turtlebot3 and test it on a real world test course
